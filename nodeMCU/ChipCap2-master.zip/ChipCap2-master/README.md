ChipCap2
========

This library is for the GE ChipCap2 Humidity & Temperature Sensor

0 ~ 100% Relative Humidity (7 Sec. response time)

-40 C ~ 125 C Temperature (5 Sec. response time)

With Low and High alarm triggers.

Various models with analog and digital output @ 3.3V or 5V operation.

Digi-Key Part Number: 235-1339-ND (Digital i2c, 5V)

Breakout Boards available at: www.circuitsforfun.com

Written by: Richard Wardlow @ Circuits for Fun, LLC

